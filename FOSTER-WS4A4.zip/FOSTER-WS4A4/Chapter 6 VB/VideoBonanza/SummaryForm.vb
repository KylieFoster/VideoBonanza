﻿'Program Name: SummarForm
'Programmer  : Kylie Foster
'Date        : 05/13/2019
'Description : This project will calculate and display the summary totals when the user clicks summary from the 
'Video Bonanza Form. 

Public Class SummaryForm

    Private Sub SummaryForm_Activated(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        'Get the summary data.

        TotalSalesTextBox.Text = VideoBonanzaRentalForm.GrandTotalDecimal.ToString("C")
        NumberCustomersTextBox.Text = VideoBonanzaRentalForm.CusomerCountInteger.ToString()
    End Sub

    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        'Close the summary form.

        Me.Hide()
    End Sub

    Private Sub NumberCustomersTextBox_TextChanged(sender As Object, e As EventArgs) Handles NumberCustomersTextBox.TextChanged

    End Sub

    Private Sub SummaryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
