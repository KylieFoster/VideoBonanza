﻿Public Class VideoBonanzaRentalForm
    ' Declare module-level constants.
    Const VHS_RENTAL_Decimal As Decimal = 1.8D
    Const DVD_RENTAL_Decimal As Decimal = 2.5D
    Const MEMBER_DISCOUNT_Decimal As Decimal = 0.1D
    Const NEW_RELEASE_VHS_Decimal As Decimal = 0.2D
    Const NEW_RELEASE_DVD_Decimal As Decimal = 0.5D


    ' Declare module-level variables for summary information.
    Private SubtotalDecimal, TotalDecimal, GrandTotalDecimal As Decimal

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        'Clear the appropriate controls.
        ItemAmountTextBox.Clear()
        QuantityTextBox.Clear()
        MovieTitleTextBox.Clear()
        NewReleaseCheckBox.Checked = False
        VHSRadioButton.Checked = False
        DVDRadioButton.Checked = False
        With MemberCheckBox.Checked = True
        End With
    End Sub

    Private Sub PrintButton_Click(sender As Object, e As EventArgs) Handles PrintButton.Click
        'Print the form.
        PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm1.Print()
    End Sub

    Private Sub OrderCompleteButton_Click(sender As Object, e As EventArgs) Handles OrderCompleteButton.Click
        'Clear the current order and add to the totals.

        Dim ReturnDialogResult As DialogResult
        Dim MessageString As String

        'Confirm clear of current order.
        MessageString = "Clear the Current Order?"
        ReturnDialogResult = MessageBox.Show(MessageString, "Order Complete?",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                                 MessageBoxDefaultButton.Button2)
        If ReturnDialogResult = DialogResult.Yes Then 'User said Yes.
            ClearButton_Click(sender, e)               'Clear the screen fields.
            SubTotalTextBox.Clear()
            DiscountTextBox.Clear()
            TotalTextBox.Clear()

            'Add to Totals.
            'Add only if not a new customer.
            If SubtotalDecimal <> 0 Then
                GrandTotalDecimal += TotalDecimal
                CustomerCountInteger += 1
                'Reset totals for next customer.
                SubtotalDecimal = 0
                TotalDecimal = 0
            End If

            'clear appropriate display items and enable check box.
            With MemberCheckBox
                .Enabled = True
                .Checked = False
            End With
        End If
    End Sub

    Private Sub SummaryButton_Click(sender As Object, e As EventArgs) Handles SummaryButton.Click
        'Calculate customer totals and average sales.

        Dim AverageDecimal As Decimal
        Dim MessageString As String

        If TotalDecimal <> 0 Then
            ' Makre sure last order is counted.
            OrderCompleteButton_Click(sender, e)
        End If

        If CustomerCountInteger > 0 Then
            'Calculate the average.
            AverageDecimal = GrandTotalDecimal / CustomerCountInteger

            ' Concatenate the message string.
            MessageString = "Customers Served:    " & CustomerCountInteger.ToString() &
            Environment.NewLine & Environment.NewLine &
            "Total Sales:     " & GrandTotalDecimal.ToString("C") &
            Environment.NewLine & Environment.NewLine

            'Display the message box.
            MessageBox.Show(MessageString, "Rental Summary",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageString = "Not sales data to summarize."
            MessageBox.Show(MessageString, "Rental Summary", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        'Return to the Sales form or quit the project.

        Dim ReturnDialogResult As DialogResult
        Dim MessageString As String

        'Confirm exit of the program.
        MessageString = "Do you wish to exit the program?"
        ReturnDialogResult = MessageBox.Show(MessageString, "Exit the program",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2)
        If ReturnDialogResult = DialogResult.Yes Then     'User said Yes.
            Me.Close() 'Exit the program.


        End If
    End Sub

    Private Sub DiscountTextBox_TextChanged(sender As Object, e As EventArgs) Handles DiscountTextBox.TextChanged

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'Display the About message box.
        Dim MessageString As String

        MessageString = "This form was developed to calculate rental prices" & Environment.NewLine &
            Environment.NewLine & "Programmed By Kylie Foster"
        MessageBox.Show(MessageString, "About Video Bonanza Rental Form", MessageBoxButtons.OK, MessageBoxIcon.Information)


    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As System.Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        ' Terminate the project.

        Me.Close()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        'Print the form.

        PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm1.Print()
    End Sub

    Private Sub SummaryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles SummaryToolStripMenuItem.Click
        'Calculate the total customers and sales. 

        Dim AverageDecimal As Decimal
        Dim MessageString As String

        If TotalDecimal <> 0 Then
            ' Makre sure last order is counted.
            OrderCompleteButton_Click(sender, e)
        End If

        If CustomerCountInteger > 0 Then
            'Calculate the average.
            AverageDecimal = GrandTotalDecimal / CustomerCountInteger

            ' Concatenate the message string.
            MessageString = "Customers Served:    " & CustomerCountInteger.ToString() &
            Environment.NewLine & Environment.NewLine &
            "Total Sales:     " & GrandTotalDecimal.ToString("C") &
            Environment.NewLine & Environment.NewLine

            'Display the message box.
            MessageBox.Show(MessageString, "Rental Summary",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageString = "Not sales data to summarize."
            MessageBox.Show(MessageString, "Rental Summary", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub CalculateToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles CalculateToolStripMenuItem.Click
        'Calculate and display the current amount to add to totals. 
        Dim PriceDecimal, DiscountDecimal, ItemAmountDecimal As Decimal
        Dim QuantityInteger As Integer


        'Find the price.
        If VHSRadioButton.Checked Then
            PriceDecimal = VHS_RENTAL_Decimal
        ElseIf DVDRadioButton.Checked Then
            PriceDecimal = DVD_RENTAL_Decimal
        End If

        'Calculate the extended price and add to order total.
        Try
            QuantityInteger = Integer.Parse(QuantityTextBox.Text)
            ItemAmountDecimal = PriceDecimal * QuantityInteger
            SubtotalDecimal += ItemAmountDecimal
            If MemberCheckBox.Checked Then
                DiscountDecimal = SubtotalDecimal * MEMBER_DISCOUNT_Decimal
            Else
                DiscountDecimal = 0
            End If
            TotalDecimal = SubtotalDecimal - DiscountDecimal
            ItemAmountTextBox.Text = ItemAmountDecimal.ToString("C")
            SubTotalTextBox.Text = SubtotalDecimal.ToString("N")
            DiscountTextBox.Text = DiscountDecimal.ToString("N")
            TotalTextBox.Text = TotalDecimal.ToString("C")
            'Allow a change only for new order.
            MemberCheckBox.Enabled = False
        Catch
            If MovieTitleTextBox.Text <> "" Then
                'Instruct user to enter movie title.
            Else
                MessageBox.Show("Movie Title is Required Entry", "Missing Data", MessageBoxButtons.OK)
                With MovieTitleTextBox
                    .Focus()
                End With

            End If
        End Try
    End Sub

    Private Sub ClearForNextItemToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles ClearForNextItemToolStripMenuItem.Click
        'Clear the appropriate controls.

        ItemAmountTextBox.Clear()
        QuantityTextBox.Clear()
        MovieTitleTextBox.Clear()
        NewReleaseCheckBox.Checked = False
        VHSRadioButton.Checked = False
        DVDRadioButton.Checked = False
        With MemberCheckBox.Checked = True
        End With
    End Sub

    Private Sub OrderCompleteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles OrderCompleteToolStripMenuItem.Click
        'Clear the current order and add to the totals.

        Dim ReturnDialogResult As DialogResult
        Dim MessageString As String

        'Confirm clear of current order.
        MessageString = "Clear the Current Order?"
        ReturnDialogResult = MessageBox.Show(MessageString, "Order Complete?",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                                 MessageBoxDefaultButton.Button2)
        If ReturnDialogResult = DialogResult.Yes Then 'User said Yes.
            ClearButton_Click(sender, e)               'Clear the screen fields.
            SubTotalTextBox.Clear()
            DiscountTextBox.Clear()
            TotalTextBox.Clear()

            'Add to Totals.
            'Add only if not a new customer.
            If SubtotalDecimal <> 0 Then
                GrandTotalDecimal += TotalDecimal
                CustomerCountInteger += 1
                'Reset totals for next customer.
                SubtotalDecimal = 0
                TotalDecimal = 0
            End If

            'clear appropriate display items and enable check box.
            With MemberCheckBox
                .Enabled = True
                .Checked = False
            End With
        End If
    End Sub

    Private Sub ColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ColorToolStripMenuItem.Click
        ' Change the color of the form.

        With ColorDialog1
            .ShowDialog()
            GroupBox1.BackColor = .Color
            GroupBox2.BackColor = .Color

        End With
    End Sub

    Private Sub FontToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontToolStripMenuItem.Click
        ' Change the font name for the labels

        With FontDialog1
            .ShowDialog()
            OrderCompleteButton.Font = .Font
            SummaryButton.Font = .Font
            PrintButton.Font = .Font
            ExitButton.Font = .Font
        End With
    End Sub

    Private Sub CalculateButton_Click(sender As Object, e As EventArgs) Handles CalculateButton.Click
        'Calculate and display the current amounts to add to totals.

        Dim PriceDecimal, DiscountDecimal, ItemAmountDecimal As Decimal
        Dim QuantityInteger As Integer


        'Find the price.
        If VHSRadioButton.Checked Then
            PriceDecimal = VHS_RENTAL_Decimal
        ElseIf DVDRadioButton.Checked Then
            PriceDecimal = DVD_RENTAL_Decimal
        End If

        'Calculate the extended price and add to order total.
        Try
            QuantityInteger = Integer.Parse(QuantityTextBox.Text)
            ItemAmountDecimal = PriceDecimal * QuantityInteger
            SubtotalDecimal += ItemAmountDecimal
            If MemberCheckBox.Checked Then
                DiscountDecimal = SubtotalDecimal * MEMBER_DISCOUNT_Decimal
            Else
                DiscountDecimal = 0
            End If
            TotalDecimal = SubtotalDecimal - DiscountDecimal
            ItemAmountTextBox.Text = ItemAmountDecimal.ToString("C")
            SubTotalTextBox.Text = SubtotalDecimal.ToString("N")
            DiscountTextBox.Text = DiscountDecimal.ToString("N")
            TotalTextBox.Text = TotalDecimal.ToString("C")
            'Allow a change only for new order.
            MemberCheckBox.Enabled = False

            If MovieTitleTextBox.Text <> "" Then
                'Instruct user to enter movie title.
            Else
                MessageBox.Show("Movie Title is Required Entry", "Missing Data", MessageBoxButtons.OK)
                With MovieTitleTextBox
                    .Focus()
                End With

            End If

        Catch QuantityException As FormatException
            MessageBox.Show("Quantity must be numeric.", "Data Entry Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation)
            With QuantityTextBox
                .Focus()
                .SelectAll()
            End With


        End Try
    End Sub

    Private CustomerCountInteger As Integer

End Class

